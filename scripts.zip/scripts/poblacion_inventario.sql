CREATE DATABASE inventario;

INSERT INTO proveedor (nombre, direccion, telefono, email) VALUES
('EcoProveedores Ltda', 'Av. Sustentable 123, Santiago', '+56911112222', 'contacto@ecoproveedores.cl'),
('Verde Natural Spa', 'Calle Verde 456, Valparaíso', '+56933334444', 'ventas@verdenatural.cl'),
('Orgánicos del Sur', 'Ruta Ecológica 789, Temuco', '+56955556666', 'info@organicosur.cl');

INSERT INTO productos (nombre, descripcion, precio, stock) VALUES
('Shampoo Ecológico', 'Shampoo biodegradable sin parabenos.', 4500.00, 100),
('Jabón Artesanal', 'Jabón hecho a mano con ingredientes naturales.', 2500.00, 200),
('Cepillo de Bambú', 'Cepillo de dientes ecológico.', 1500.00, 300),
('Bolsa Reutilizable', 'Bolsa de algodón orgánico.', 2000.00, 150);

INSERT INTO pedidos (estado) VALUES
('Pendiente'),
('Enviado'),
('Entregado');







