SELECT * FROM pedido;
INSERT INTO pedido(cantidad, cliente, producto, total, fecha) VALUES
(2, 'Camila Soto', 'Cajas', 1800.0, '2025-04-11 00:00:00'),
(1, 'Joaquin Lazo', 'Pan Integral', 1200.0, '2025-04-23 00:00:00'),
(3, 'Martina Sanhueza', 'Cucharas', 2700.0, '2025-04-17 00:00:00'),
(4, 'Juan Pablo', 'Mesa', 15000.0, '2025-05-10 00:00:00'),
(2, 'Valentina Lopez', 'Yogurt', 2200.0, '2025-05-15 00:00:00');