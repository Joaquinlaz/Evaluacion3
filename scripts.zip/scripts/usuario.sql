CREATE DATABASE usuarios_db;
INSERT INTO usuario (id, nombre, correo, rol) VALUES
(1, 'Ana Torres', 'ana.torres@ecomarket.com', 'Administrador'),
(2, 'Luis Rojas', 'luis.rojas@ecomarket.com', 'Gerente de Tienda'),
(3, 'María López', 'maria.lopez@ecomarket.com', 'Empleado de Ventas'),
(4, 'Pedro Núñez', 'pedro.nunez@ecomarket.com', 'Cliente'),
(5, 'Laura Silva', 'laura.silva@ecomarket.com', 'Cliente'),
(6, 'Jorge Soto', 'jorge.soto@ecomarket.com', 'Empleado de Ventas'),
(7, 'Claudia Vega', 'claudia.vega@ecomarket.com', 'Gerente de Tienda'),
(8, 'Ricardo Paredes', 'ricardo.paredes@ecomarket.com', 'Administrador'),
(9, 'Daniela Reyes', 'daniela.reyes@ecomarket.com', 'Cliente'),
(10, 'Tomás Herrera', 'tomas.herrera@ecomarket.com', 'Empleado de Ventas');
