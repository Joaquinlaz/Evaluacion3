

INSERT INTO reporte (tipo, contenido, fecha)
VALUES 
  ('ventas', 'Ventas del día 19 de mayo.', '2025-05-19'),
  ('inventario', 'Inventario actualizado al 19 de mayo.', '2025-05-19'),
  ('tiendas', 'Reporte de tiendas activas en la región.', '2025-05-19');
  
  SELECT * FROM reporte; 