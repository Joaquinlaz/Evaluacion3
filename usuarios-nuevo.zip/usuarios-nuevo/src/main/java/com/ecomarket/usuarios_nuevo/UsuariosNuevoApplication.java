package com.ecomarket.usuarios_nuevo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UsuariosNuevoApplication {

    public static void main(String[] args) {
        SpringApplication.run(UsuariosNuevoApplication.class, args);
    }

}