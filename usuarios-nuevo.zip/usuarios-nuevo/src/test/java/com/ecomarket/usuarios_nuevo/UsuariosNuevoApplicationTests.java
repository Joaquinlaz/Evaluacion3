package com.ecomarket.usuarios_nuevo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsuariosNuevoApplicationTests {

    @Test
    void contextLoads() {
        // Test vacío que valida el contexto
    }
}
